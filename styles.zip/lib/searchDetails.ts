const initialDetails = [
    {
      id: 1,
      course: "area_of_triangles",
      subject: "maths",
      difficulty: "medium"
    },
    {
      id: 2,
      course: "pythagoras_theorem",
      subject: "maths",
      difficulty: "medium"
    },
    {
      id: 3,
      course: "reflection_of_light",
      subject: "physics",
      difficulty: "medium"
    },
    {
      id: 4,
      course: "ray_optics",
      subject: "physics",
      difficulty: "hard"
    },
    {
      id: 5,
      course: "structure_of_an_atom",
      subject: "chemistry",
      difficulty: "medium"
    },
    {
      id: 6,
      course: "introduction_to_organic_chemistry",
      subject: "chemistry",
      difficulty: "medium"
    },
    {
      id: 7,
      course: "cell",
      subject: "biology",
      difficulty: "medium"
    },
    {
      id: 8,
      course: "the_human_body",
      subject: "biology",
      difficulty: "medium"
    },
  ];
  
  export default initialDetails;