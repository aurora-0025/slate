/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./context/AuthContext.tsx":
/*!*********************************!*\
  !*** ./context/AuthContext.tsx ***!
  \*********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"AuthContextProvider\": () => (/* binding */ AuthContextProvider),\n/* harmony export */   \"useAuth\": () => (/* binding */ useAuth)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/auth */ \"firebase/auth\");\n/* harmony import */ var _firebase_clientApp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../firebase/clientApp */ \"./firebase/clientApp.ts\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_auth__WEBPACK_IMPORTED_MODULE_2__, _firebase_clientApp__WEBPACK_IMPORTED_MODULE_3__]);\n([firebase_auth__WEBPACK_IMPORTED_MODULE_2__, _firebase_clientApp__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\nconst AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});\nconst useAuth = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthContext)\n;\nconst AuthContextProvider = ({ children  })=>{\n    const { 0: user1 , 1: setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        const unsubscribe = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.onAuthStateChanged)(_firebase_clientApp__WEBPACK_IMPORTED_MODULE_3__.auth, (user)=>{\n            if (user) {\n                setUser({\n                    uid: user.uid,\n                    email: user.email,\n                    displayName: user.displayName\n                });\n            } else {\n                setUser(null);\n            }\n            setLoading(false);\n        });\n        return ()=>unsubscribe()\n        ;\n    }, []);\n    const signUp = (email, password)=>{\n        (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.createUserWithEmailAndPassword)(_firebase_clientApp__WEBPACK_IMPORTED_MODULE_3__.auth, email, password).then(()=>{\n            console.log(\"loggedIn\");\n        }).catch((err)=>{\n            console.log(err.errorMessage);\n        });\n    };\n    const logIn = (email, password)=>{\n        (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.signInWithEmailAndPassword)(_firebase_clientApp__WEBPACK_IMPORTED_MODULE_3__.auth, email, password).then((userCredential)=>{\n            // Signed in \n            const user = userCredential.user;\n            return user;\n        }).catch((error)=>{\n            return error.message;\n        });\n    };\n    const logOut = async ()=>{\n        setUser(null);\n        await (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.signOut)(_firebase_clientApp__WEBPACK_IMPORTED_MODULE_3__.auth);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(AuthContext.Provider, {\n        value: {\n            user: user1,\n            logIn,\n            signUp,\n            logOut\n        },\n        children: loading ? null : children\n    }, void 0, false, {\n        fileName: \"D:\\\\projects\\\\nodejs\\\\brilliantko\\\\context\\\\AuthContext.tsx\",\n        lineNumber: 55,\n        columnNumber: 9\n    }, undefined);\n};\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb250ZXh0L0F1dGhDb250ZXh0LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBO0FBQXVFO0FBRWdEO0FBQzFFO0FBRTdDLE1BQU1TLFdBQVcsaUJBQUdULG9EQUFhLENBQU0sRUFBRSxDQUFDO0FBRW5DLE1BQU1VLE9BQU8sR0FBRyxJQUFNVCxpREFBVSxDQUFDUSxXQUFXLENBQUM7QUFBQTtBQUc3QyxNQUFNRSxtQkFBbUIsR0FBRyxDQUFDLEVBQUNDLFFBQVEsR0FBK0IsR0FBSTtJQUU1RSxNQUFNLEVBWlYsR0FZV0MsS0FBSSxHQVpmLEdBWWlCQyxPQUFPLE1BQUtYLCtDQUFRLENBQU0sSUFBSSxDQUFDO0lBQzVDLE1BQU0sRUFiVixHQWFXWSxPQUFPLEdBYmxCLEdBYW9CQyxVQUFVLE1BQUliLCtDQUFRLENBQVUsSUFBSSxDQUFDO0lBRXJERCxnREFBUyxDQUFDLElBQU07UUFDWixNQUFNZSxXQUFXLEdBQUdaLGlFQUFrQixDQUFDRyxxREFBSSxFQUFFLENBQUNLLElBQUksR0FBSztZQUNuRCxJQUFHQSxJQUFJLEVBQUU7Z0JBQ0xDLE9BQU8sQ0FBQztvQkFDSkksR0FBRyxFQUFFTCxJQUFJLENBQUNLLEdBQUc7b0JBQ2JDLEtBQUssRUFBRU4sSUFBSSxDQUFDTSxLQUFLO29CQUNqQkMsV0FBVyxFQUFFUCxJQUFJLENBQUNPLFdBQVc7aUJBQ2hDLENBQUM7YUFDTCxNQUFNO2dCQUNITixPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDakI7WUFDREUsVUFBVSxDQUFDLEtBQUssQ0FBQztTQUNwQixDQUFDO1FBRUYsT0FBTyxJQUFNQyxXQUFXLEVBQUU7UUFBQSxDQUFDO0tBQzlCLEVBQUUsRUFBRSxDQUFDO0lBRU4sTUFBTUksTUFBTSxHQUFHLENBQUNGLEtBQWEsRUFBRUcsUUFBZ0IsR0FBSztRQUNoRGxCLDZFQUE4QixDQUFDSSxxREFBSSxFQUFFVyxLQUFLLEVBQUVHLFFBQVEsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSTtZQUMzREMsT0FBTyxDQUFDQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDM0IsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQ0MsR0FBRyxHQUFHO1lBQ1pILE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRSxHQUFHLENBQUNDLFlBQVksQ0FBQyxDQUFDO1NBQ2pDLENBQUM7S0FDTDtJQUNELE1BQU1DLEtBQUssR0FBRyxDQUFDVixLQUFhLEVBQUVHLFFBQWdCLEdBQUs7UUFDL0NoQix5RUFBMEIsQ0FBQ0UscURBQUksRUFBRVcsS0FBSyxFQUFFRyxRQUFRLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUNPLGNBQWMsR0FBSztZQUN2RSxhQUFhO1lBQ2IsTUFBTWpCLElBQUksR0FBR2lCLGNBQWMsQ0FBQ2pCLElBQUk7WUFDaEMsT0FBT0EsSUFBSSxDQUFDO1NBQ2IsQ0FBQyxDQUFDYSxLQUFLLENBQUMsQ0FBQ0ssS0FBSyxHQUFHO1lBQ2hCLE9BQU9BLEtBQUssQ0FBQ0MsT0FBTyxDQUFDO1NBQ3RCLENBQUM7S0FDUDtJQUNELE1BQU1DLE1BQU0sR0FBRyxVQUFZO1FBQ3ZCbkIsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2YsTUFBTVAsc0RBQU8sQ0FBQ0MscURBQUksQ0FBQyxDQUFDO0tBQ3RCO0lBRUQscUJBQ0ksOERBQUNDLFdBQVcsQ0FBQ3lCLFFBQVE7UUFBQ0MsS0FBSyxFQUFFO1lBQUV0QixJQUFJLEVBQUpBLEtBQUk7WUFBRWdCLEtBQUs7WUFBRVIsTUFBTTtZQUFFWSxNQUFNO1NBQUU7a0JBQ3ZEbEIsT0FBTyxHQUFFLElBQUksR0FBR0gsUUFBUTs7Ozs7aUJBQ04sQ0FDMUI7Q0FDSiIsInNvdXJjZXMiOlsid2VicGFjazovL2JyaWxsaWFudGtvLy4vY29udGV4dC9BdXRoQ29udGV4dC50c3g/ZmRmZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5pbXBvcnQgeyBjcmVhdGVVc2VyV2l0aEVtYWlsQW5kUGFzc3dvcmQsIG9uQXV0aFN0YXRlQ2hhbmdlZCwgc2lnbkluV2l0aEVtYWlsQW5kUGFzc3dvcmQsIHNpZ25PdXQgfSBmcm9tICdmaXJlYmFzZS9hdXRoJ1xyXG5pbXBvcnQgeyBhdXRoIH0gZnJvbSBcIi4uL2ZpcmViYXNlL2NsaWVudEFwcFwiO1xyXG5cclxuY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0PGFueT4oe30pO1xyXG5cclxuZXhwb3J0IGNvbnN0IHVzZUF1dGggPSAoKSA9PiB1c2VDb250ZXh0KEF1dGhDb250ZXh0KVxyXG5cclxuXHJcbmV4cG9ydCBjb25zdCBBdXRoQ29udGV4dFByb3ZpZGVyID0gKHtjaGlsZHJlbn0gOiB7Y2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZX0pID0+e1xyXG5cclxuICAgIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSAgPSB1c2VTdGF0ZTxhbnk+KG51bGwpXHJcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZTxCb29sZWFuPih0cnVlKVxyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBvbkF1dGhTdGF0ZUNoYW5nZWQoYXV0aCwgKHVzZXIpID0+IHtcclxuICAgICAgICAgICAgaWYodXNlcikge1xyXG4gICAgICAgICAgICAgICAgc2V0VXNlcih7XHJcbiAgICAgICAgICAgICAgICAgICAgdWlkOiB1c2VyLnVpZCxcclxuICAgICAgICAgICAgICAgICAgICBlbWFpbDogdXNlci5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5TmFtZTogdXNlci5kaXNwbGF5TmFtZVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHNldFVzZXIobnVsbCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gKCkgPT4gdW5zdWJzY3JpYmUoKTtcclxuICAgIH0sIFtdKVxyXG5cclxuICAgIGNvbnN0IHNpZ25VcCA9IChlbWFpbDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgY3JlYXRlVXNlcldpdGhFbWFpbEFuZFBhc3N3b3JkKGF1dGgsIGVtYWlsLCBwYXNzd29yZCkudGhlbigoKT0+e1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnbG9nZ2VkSW4nKTtcclxuICAgICAgICB9KS5jYXRjaCgoZXJyKT0+e1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIuZXJyb3JNZXNzYWdlKTtcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgbG9nSW4gPSAoZW1haWw6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIHNpZ25JbldpdGhFbWFpbEFuZFBhc3N3b3JkKGF1dGgsIGVtYWlsLCBwYXNzd29yZCkudGhlbigodXNlckNyZWRlbnRpYWwpID0+IHtcclxuICAgICAgICAgICAgLy8gU2lnbmVkIGluIFxyXG4gICAgICAgICAgICBjb25zdCB1c2VyID0gdXNlckNyZWRlbnRpYWwudXNlcjtcclxuICAgICAgICAgICAgcmV0dXJuIHVzZXI7XHJcbiAgICAgICAgICB9KS5jYXRjaCgoZXJyb3IpPT57XHJcbiAgICAgICAgICAgIHJldHVybihlcnJvci5tZXNzYWdlKVxyXG4gICAgICAgICAgfSlcclxuICAgIH1cclxuICAgIGNvbnN0IGxvZ091dCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICBzZXRVc2VyKG51bGwpO1xyXG4gICAgICAgYXdhaXQgc2lnbk91dChhdXRoKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxBdXRoQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyB1c2VyLCBsb2dJbiwgc2lnblVwLCBsb2dPdXQgfX0+XHJcbiAgICAgICAgICAgIHtsb2FkaW5nPyBudWxsIDogY2hpbGRyZW59XHJcbiAgICAgICAgPC9BdXRoQ29udGV4dC5Qcm92aWRlcj5cclxuICAgIClcclxufSJdLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiY3JlYXRlVXNlcldpdGhFbWFpbEFuZFBhc3N3b3JkIiwib25BdXRoU3RhdGVDaGFuZ2VkIiwic2lnbkluV2l0aEVtYWlsQW5kUGFzc3dvcmQiLCJzaWduT3V0IiwiYXV0aCIsIkF1dGhDb250ZXh0IiwidXNlQXV0aCIsIkF1dGhDb250ZXh0UHJvdmlkZXIiLCJjaGlsZHJlbiIsInVzZXIiLCJzZXRVc2VyIiwibG9hZGluZyIsInNldExvYWRpbmciLCJ1bnN1YnNjcmliZSIsInVpZCIsImVtYWlsIiwiZGlzcGxheU5hbWUiLCJzaWduVXAiLCJwYXNzd29yZCIsInRoZW4iLCJjb25zb2xlIiwibG9nIiwiY2F0Y2giLCJlcnIiLCJlcnJvck1lc3NhZ2UiLCJsb2dJbiIsInVzZXJDcmVkZW50aWFsIiwiZXJyb3IiLCJtZXNzYWdlIiwibG9nT3V0IiwiUHJvdmlkZXIiLCJ2YWx1ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./context/AuthContext.tsx\n");

/***/ }),

/***/ "./firebase/clientApp.ts":
/*!*******************************!*\
  !*** ./firebase/clientApp.ts ***!
  \*******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"auth\": () => (/* binding */ auth),\n/* harmony export */   \"db\": () => (/* binding */ db)\n/* harmony export */ });\n/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/app */ \"firebase/app\");\n/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/firestore */ \"firebase/firestore\");\n/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/auth */ \"firebase/auth\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__, firebase_auth__WEBPACK_IMPORTED_MODULE_2__]);\n([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__, firebase_auth__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\nconst firebaseConfig = {\n    apiKey: \"AIzaSyDlXQ6UqmRitOiq2unDS9nVQpPrFZ6VQY8\",\n    authDomain: \"auth-development-4cbcc.firebaseapp.com\",\n    projectId: \"auth-development-4cbcc\",\n    storageBucket: \"auth-development-4cbcc.appspot.com\",\n    messagingSenderId: \"15416203173\",\n    appId: \"1:15416203173:web:7843863798ff94370bfa4c\"\n};\nconst app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);\nconst db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getFirestore)();\nconst auth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.getAuth)();\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9maXJlYmFzZS9jbGllbnRBcHAudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBNkM7QUFDSztBQUNWO0FBRXhDLE1BQU1HLGNBQWMsR0FBRztJQUNuQkMsTUFBTSxFQUFFLHlDQUF5QztJQUNqREMsVUFBVSxFQUFFLHdDQUF3QztJQUNwREMsU0FBUyxFQUFFLHdCQUF3QjtJQUNuQ0MsYUFBYSxFQUFFLG9DQUFvQztJQUNuREMsaUJBQWlCLEVBQUUsYUFBYTtJQUNoQ0MsS0FBSyxFQUFFLDBDQUEwQztDQUNsRDtBQUdILE1BQU1DLEdBQUcsR0FBR1YsMkRBQWEsQ0FBQ0csY0FBYyxDQUFDO0FBRWxDLE1BQU1RLEVBQUUsR0FBR1YsZ0VBQVksRUFBRTtBQUV6QixNQUFNVyxJQUFJLEdBQUdWLHNEQUFPLEVBQUUsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2JyaWxsaWFudGtvLy4vZmlyZWJhc2UvY2xpZW50QXBwLnRzPzI1ODkiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaW5pdGlhbGl6ZUFwcCB9IGZyb20gXCJmaXJlYmFzZS9hcHBcIjtcclxuaW1wb3J0IHsgZ2V0RmlyZXN0b3JlIH0gZnJvbSBcImZpcmViYXNlL2ZpcmVzdG9yZVwiO1xyXG5pbXBvcnQgeyBnZXRBdXRoIH0gZnJvbSBcImZpcmViYXNlL2F1dGhcIjtcclxuXHJcbmNvbnN0IGZpcmViYXNlQ29uZmlnID0ge1xyXG4gICAgYXBpS2V5OiBcIkFJemFTeURsWFE2VXFtUml0T2lxMnVuRFM5blZRcFByRlo2VlFZOFwiLFxyXG4gICAgYXV0aERvbWFpbjogXCJhdXRoLWRldmVsb3BtZW50LTRjYmNjLmZpcmViYXNlYXBwLmNvbVwiLFxyXG4gICAgcHJvamVjdElkOiBcImF1dGgtZGV2ZWxvcG1lbnQtNGNiY2NcIixcclxuICAgIHN0b3JhZ2VCdWNrZXQ6IFwiYXV0aC1kZXZlbG9wbWVudC00Y2JjYy5hcHBzcG90LmNvbVwiLFxyXG4gICAgbWVzc2FnaW5nU2VuZGVySWQ6IFwiMTU0MTYyMDMxNzNcIixcclxuICAgIGFwcElkOiBcIjE6MTU0MTYyMDMxNzM6d2ViOjc4NDM4NjM3OThmZjk0MzcwYmZhNGNcIlxyXG4gIH07XHJcblxyXG5cclxuY29uc3QgYXBwID0gaW5pdGlhbGl6ZUFwcChmaXJlYmFzZUNvbmZpZyk7XHJcblxyXG5leHBvcnQgY29uc3QgZGIgPSBnZXRGaXJlc3RvcmUoKVxyXG5cclxuZXhwb3J0IGNvbnN0IGF1dGggPSBnZXRBdXRoKCk7Il0sIm5hbWVzIjpbImluaXRpYWxpemVBcHAiLCJnZXRGaXJlc3RvcmUiLCJnZXRBdXRoIiwiZmlyZWJhc2VDb25maWciLCJhcGlLZXkiLCJhdXRoRG9tYWluIiwicHJvamVjdElkIiwic3RvcmFnZUJ1Y2tldCIsIm1lc3NhZ2luZ1NlbmRlcklkIiwiYXBwSWQiLCJhcHAiLCJkYiIsImF1dGgiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./firebase/clientApp.ts\n");

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _context_AuthContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../context/AuthContext */ \"./context/AuthContext.tsx\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _components_protectedRoute__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/protectedRoute */ \"./pages/components/protectedRoute.tsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_AuthContext__WEBPACK_IMPORTED_MODULE_2__, _components_protectedRoute__WEBPACK_IMPORTED_MODULE_4__]);\n([_context_AuthContext__WEBPACK_IMPORTED_MODULE_2__, _components_protectedRoute__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    const noAuthRequired = [\n        \"/login\",\n        \"/signup\",\n        \"/\",\n        \"/physics\",\n        \"/chemistry\",\n        \"/biology\",\n        \"maths\"\n    ];\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_context_AuthContext__WEBPACK_IMPORTED_MODULE_2__.AuthContextProvider, {\n        children: noAuthRequired.includes(router.pathname) ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"D:\\\\projects\\\\nodejs\\\\brilliantko\\\\pages\\\\_app.tsx\",\n            lineNumber: 15,\n            columnNumber: 9\n        }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_protectedRoute__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\projects\\\\nodejs\\\\brilliantko\\\\pages\\\\_app.tsx\",\n                lineNumber: 18,\n                columnNumber: 11\n            }, this)\n        }, void 0, false, {\n            fileName: \"D:\\\\projects\\\\nodejs\\\\brilliantko\\\\pages\\\\_app.tsx\",\n            lineNumber: 17,\n            columnNumber: 9\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\projects\\\\nodejs\\\\brilliantko\\\\pages\\\\_app.tsx\",\n        lineNumber: 13,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUF1QztBQUNxQjtBQUM5QjtBQUMwQjtBQUV4RCxTQUFTRyxLQUFLLENBQUMsRUFBRUMsU0FBUyxHQUFFQyxTQUFTLEdBQUUsRUFBRTtJQUV2QyxNQUFNQyxjQUFjLEdBQUc7UUFBQyxRQUFRO1FBQUUsU0FBUztRQUFFLEdBQUc7UUFBRSxVQUFVO1FBQUUsWUFBWTtRQUFFLFVBQVU7UUFBRSxPQUFPO0tBQUM7SUFFaEcsTUFBTUMsTUFBTSxHQUFHUCxzREFBUyxFQUFFO0lBRTFCLHFCQUNFLDhEQUFDQyxxRUFBbUI7a0JBQ2pCSyxjQUFjLENBQUNFLFFBQVEsQ0FBQ0QsTUFBTSxDQUFDRSxRQUFRLENBQUMsaUJBQ3ZDLDhEQUFDTCxTQUFTO1lBQUUsR0FBR0MsU0FBUzs7Ozs7Z0JBQUksaUJBRTVCLDhEQUFDSCxrRUFBYztzQkFDYiw0RUFBQ0UsU0FBUztnQkFBRSxHQUFHQyxTQUFTOzs7OztvQkFBSTs7Ozs7Z0JBQ2I7Ozs7O1lBRUMsQ0FFdkI7Q0FDRjtBQUVELGlFQUFlRixLQUFLIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYnJpbGxpYW50a28vLi9wYWdlcy9fYXBwLnRzeD8yZmJlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xuaW1wb3J0IHsgQXV0aENvbnRleHRQcm92aWRlciB9IGZyb20gJy4uL2NvbnRleHQvQXV0aENvbnRleHQnXG5pbXBvcnQgJy4uL3N0eWxlcy9nbG9iYWxzLmNzcydcbmltcG9ydCBQcm90ZWN0ZWRSb3V0ZSBmcm9tICcuL2NvbXBvbmVudHMvcHJvdGVjdGVkUm91dGUnXG5cbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuXG4gIGNvbnN0IG5vQXV0aFJlcXVpcmVkID0gWycvbG9naW4nLCAnL3NpZ251cCcsICcvJywgJy9waHlzaWNzJywgJy9jaGVtaXN0cnknLCAnL2Jpb2xvZ3knLCAnbWF0aHMnXVxuXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG5cbiAgcmV0dXJuIChcbiAgICA8QXV0aENvbnRleHRQcm92aWRlcj5cbiAgICAgIHtub0F1dGhSZXF1aXJlZC5pbmNsdWRlcyhyb3V0ZXIucGF0aG5hbWUpID8gKFxuICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICApOihcbiAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxuICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cbiAgICAgICl9XG4gICAgPC9BdXRoQ29udGV4dFByb3ZpZGVyPlxuICAgIFxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE15QXBwXG4iXSwibmFtZXMiOlsidXNlUm91dGVyIiwiQXV0aENvbnRleHRQcm92aWRlciIsIlByb3RlY3RlZFJvdXRlIiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJub0F1dGhSZXF1aXJlZCIsInJvdXRlciIsImluY2x1ZGVzIiwicGF0aG5hbWUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./pages/components/protectedRoute.tsx":
/*!*********************************************!*\
  !*** ./pages/components/protectedRoute.tsx ***!
  \*********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _context_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../context/AuthContext */ \"./context/AuthContext.tsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_AuthContext__WEBPACK_IMPORTED_MODULE_3__]);\n_context_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\nconst ProtectedRoute = ({ children  })=>{\n    const { user  } = (0,_context_AuthContext__WEBPACK_IMPORTED_MODULE_3__.useAuth)();\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        if (!user) {\n            router.push(\"/\");\n        }\n    }, [\n        router,\n        user\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: user ? children : null\n    }, void 0, false);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProtectedRoute);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9jb21wb25lbnRzL3Byb3RlY3RlZFJvdXRlLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBO0FBQXdDO0FBQ0E7QUFDWTtBQUVwRCxNQUFNSSxjQUFjLEdBQUcsQ0FBQyxFQUFDQyxRQUFRLEdBQWdDLEdBQU07SUFDbkUsTUFBTSxFQUFDQyxJQUFJLEdBQUMsR0FBR0gsNkRBQU8sRUFBRTtJQUN4QixNQUFNSSxNQUFNLEdBQUdQLHNEQUFTLEVBQUU7SUFFMUJFLGdEQUFTLENBQUMsSUFBSTtRQUNWLElBQUcsQ0FBQ0ksSUFBSSxFQUFDO1lBQ0xDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLEdBQUcsQ0FBQztTQUNuQjtLQUNKLEVBQUU7UUFBQ0QsTUFBTTtRQUFFRCxJQUFJO0tBQUMsQ0FBQztJQUVsQixxQkFDSTtrQkFBR0EsSUFBSSxHQUFHRCxRQUFRLEdBQUcsSUFBSTtxQkFBSSxDQUNoQztDQUNKO0FBR0QsaUVBQWVELGNBQWMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9icmlsbGlhbnRrby8uL3BhZ2VzL2NvbXBvbmVudHMvcHJvdGVjdGVkUm91dGUudHN4PzAxZjIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xyXG5pbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9jb250ZXh0L0F1dGhDb250ZXh0JztcclxuXHJcbmNvbnN0IFByb3RlY3RlZFJvdXRlID0gKHtjaGlsZHJlbn0gOiB7Y2hpbGRyZW4gOiBSZWFjdC5SZWFjdE5vZGV9KSA9PiAge1xyXG4gICAgY29uc3Qge3VzZXJ9ID0gdXNlQXV0aCgpO1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpPT57XHJcbiAgICAgICAgaWYoIXVzZXIpe1xyXG4gICAgICAgICAgICByb3V0ZXIucHVzaCgnLycpXHJcbiAgICAgICAgfVxyXG4gICAgfSwgW3JvdXRlciwgdXNlcl0pXHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Pnt1c2VyID8gY2hpbGRyZW4gOiBudWxsfTwvPlxyXG4gICAgKVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvdGVjdGVkUm91dGUiXSwibmFtZXMiOlsidXNlUm91dGVyIiwiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VBdXRoIiwiUHJvdGVjdGVkUm91dGUiLCJjaGlsZHJlbiIsInVzZXIiLCJyb3V0ZXIiLCJwdXNoIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/components/protectedRoute.tsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "firebase/app":
/*!*******************************!*\
  !*** external "firebase/app" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/app");;

/***/ }),

/***/ "firebase/auth":
/*!********************************!*\
  !*** external "firebase/auth" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/auth");;

/***/ }),

/***/ "firebase/firestore":
/*!*************************************!*\
  !*** external "firebase/firestore" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = import("firebase/firestore");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();